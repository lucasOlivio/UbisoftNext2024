#pragma once

namespace MyEngine
{
    enum eKeyCodes
    {
        UNKNOWN = -1,
        SPACE = 32,
        A = 65,
        D = 68,
        E = 69,
        S = 83,
        W = 87
    };
}
