#pragma once

namespace MyEngine
{
	// Numeric types alias
	typedef __int32 int32_t;
	typedef unsigned __int32 uint32_t;
	typedef unsigned __int8 uint8_t;

	typedef unsigned int uint;
}