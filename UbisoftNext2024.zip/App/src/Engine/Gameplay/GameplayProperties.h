#pragma once

namespace MyEngine
{
	enum eGameStates
	{
		NOT_STARTED = 0,
		STARTED,
		RUNNING,
		LEVELUP,
		GAMEOVER
	};
}
